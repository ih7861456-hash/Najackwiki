const express = require('express');
const { body } = require('express-validator');
const { Address4, Address6 } = require('ip-address');

const utils = require('../utils');
const namumarkUtils = require('../utils/namumark/utils');
const middleware = require('../utils/middleware');
const {
    BlockHistoryTypes,
    AuditLogTypes,
    SignupPolicy,
    AllPermissions,
    ProtectedPermissions,
    NoGrantPermissions,
    AlwaysProtectedPermissions
} = require('../utils/types');

const User = require('../schemas/user');
const ACLGroup = require('../schemas/aclGroup');
const ACLGroupItem = require('../schemas/aclGroupItem');
const BlockHistory = require('../schemas/blockHistory');
const AuditLog = require('../schemas/auditLog');

const app = express.Router();

const aclGroupsQuery = req => ({
    ...(req.permissions.includes('developer') ? {} : {
        $or: [
            ...(req.permissions.includes('aclgroup') ? [{
                accessPerms: {
                    $size: 0
                }
            }] : []),
            {
                accessPerms: {
                    $in: req.permissions
                }
            },
            {
                managePerms: {
                    $in: req.permissions
                }
            }
        ]
    })
});
const sortAclGroups = rawAclGroups => [...new Set([
    ...(config.aclgroup_order ?? []).map(a => rawAclGroups.find(b => b.name === a)).filter(a => a),
    ...rawAclGroups
])];

const groupPermChecker = (req, group, key) => {
    if(!group) return false;

    if(req.permissions.includes('developer')) return true;
    if(key !== 'managePerms' && groupPermChecker(req, group, 'managePerms'))
        return true;
    if(key !== 'accessPerms' && key !== 'managePerms' && !groupPermChecker(req, group, 'accessPerms'))
        return false;

    const perms = group[key] ?? [];
    return perms.length
        ? perms.some(a => req.permissions.includes(a))
        : req.permissions.includes('aclgroup');
}

const getACLGroup = async (req, res) => {
    const rawAclGroups = await ACLGroup.find(aclGroupsQuery(req));
    const aclGroups = sortAclGroups(rawAclGroups);
    const selectedGroup = aclGroups.find(a => a.name === req.query.group) ?? aclGroups[0];

    let query;
    let groupItems;
    if(selectedGroup) {
        query = {
            aclGroup: selectedGroup.uuid
        };

        const until = parseInt(req.query.until);
        const from = parseInt(req.query.from);
        if(!isNaN(until)) query.id = { $gte: until };
        else if(!isNaN(from)) query.id = { $lte: from };

        groupItems = await ACLGroupItem.find(query)
            .sort({ id: query.id?.$gte ? 1 : -1 })
            .limit(50)
            .lean();

        if(query.id?.$gte) groupItems.reverse();
    }

    let prevItem;
    let nextItem;
    if(groupItems?.length) {
        prevItem = await ACLGroupItem.findOne({
            ...query,
            id: {$gt: groupItems[0].id}
        }).sort({ id: 1 });
        nextItem = await ACLGroupItem.findOne({
            ...query,
            id: { $lt: groupItems[groupItems.length - 1].id }
        }).sort({ id: -1 });

        groupItems = await utils.findUsers(req, groupItems);
    }

    res.renderSkin('aclgroup', {
        contentName: 'admin/aclgroup',
        serverData: {
            aclGroups: aclGroups.map(a => ({
                ...utils.onlyKeys(a, [
                    'uuid',
                    'name'
                ]),
                managable: groupPermChecker(req, a, 'managePerms')
            })),
            selectedGroup: utils.onlyKeys(selectedGroup, [
                'uuid',
                'name'
            ]),
            addable: groupPermChecker(req, selectedGroup, 'addPerms'),
            removable: groupPermChecker(req, selectedGroup, 'removePerms'),
            permissions: {
                aclgroup: req.permissions.includes('aclgroup'),
                hidelog: req.permissions.includes('aclgroup_hidelog')
            },
            groupItems: utils.onlyKeys(groupItems, [
                'id',
                'uuid',
                'user',
                'ip',
                'note',
                'createdAt',
                'expiresAt'
            ]),
            prevItem: prevItem?.id,
            nextItem: nextItem?.id
        }
    });
}
module.exports.getACLGroup = getACLGroup;

app.get('/aclgroup', getACLGroup);

app.get('/aclgroup/groups', middleware.internal, async (req, res) => {
    const rawAclGroups = await ACLGroup.find(aclGroupsQuery(req));
    const aclGroups = sortAclGroups(rawAclGroups);
    res.json(aclGroups.map(a => ({
        uuid: a.uuid,
        name: a.name
    })));
});

app.post('/aclgroup/group_add',
    middleware.permission('aclgroup'),
    body('name')
        .isLength({ max: 64 })
        .withMessage('routes.aclgroup.errors.long_group_name'),
    middleware.fieldErrors,
    async (req, res) => {
    const name = req.body.name;

    if(!name) return res.status(400).send(req.t('routes.aclgroup.errors.missing_group_name'));

    const checkExists = await ACLGroup.exists({ name });
    if(checkExists) return res.status(409).send(req.t('routes.aclgroup.errors.dup_group_name'));

    const newGroup = {
        name
    };

    if(name === req.t('default_aclgroups.blocked_user')) {
        newGroup.forBlock = true;
        newGroup.signupPolicy = SignupPolicy.Block;
        newGroup.userCSS = 'color: gray !important; text-decoration: line-through !important;';
        newGroup.accessPerms = ['admin'];
        newGroup.addPerms = ['admin'];
        newGroup.removePerms = ['admin'];
        newGroup.managePerms = ['developer'];
    }
    else if(name === req.t('default_aclgroups.block_edit_request')) {
        newGroup.accessPerms = ['admin'];
        newGroup.addPerms = ['admin'];
        newGroup.removePerms = ['admin'];
    }
    else if(name === req.t('default_aclgroups.login_allowed_block')
        || name.includes(req.t('default_aclgroups.isp_keyword'))
        || name.toLowerCase().includes('vpn')) {
        newGroup.signupPolicy = SignupPolicy.RequireVerification;
        newGroup.userCSS = 'color: green !important; text-decoration: line-through !important;';
        newGroup.accessPerms = ['admin'];
        newGroup.addPerms = ['admin'];
        newGroup.removePerms = ['admin'];
    }
    else if(name.startsWith(req.t('default_aclgroups.warn_keyword'))) {
        newGroup.selfRemovable = true;
        newGroup.accessPerms = ['any'];
        newGroup.addPerms = ['admin'];
        newGroup.removePerms = ['admin'];
        newGroup.selfRemoveNote = req.t('default_aclgroups.checked_message');
        newGroup.aclMessage = `
${req.t('default_aclgroups.warn_message')}

<a href="/aclgroup/self_remove?id={id}">[${req.t('default_aclgroups.checked_message')} #{id}]</a>
${req.t('acl.deny_string.reason')}: {note}
        `.trim().replaceAll('\n', '<br>');
    }

    await ACLGroup.create(newGroup);
    await AuditLog.create({
        user: req.user.uuid,
        action: AuditLogTypes.ACLGroupCreate,
        target: name
    });

    res.reload();
});

app.post('/aclgroup/group_remove', async (req, res) => {
    const uuid = req.body.uuid;
    const target = await ACLGroup.findOne({ ...aclGroupsQuery(req), uuid });

    if(!target) return res.status(404).send(req.t('routes.aclgroup.errors.group_not_found'));
    if(!groupPermChecker(req, target, 'managePerms')) return res.status(403).send(req.t('errors.missing_permission'));

    const deleted = await ACLGroup.findOneAndDelete({ uuid });
    await AuditLog.create({
        user: req.user.uuid,
        action: AuditLogTypes.ACLGroupDelete,
        target: deleted.name
    });

    res.redirect('/aclgroup');
});

const postACLGroupValidate = [
    (req, res, next) => {
        req.modifiedBody = {};
        next();
    },
    body('group')
        .if((value, { req }) => req.isAPI)
        .isString()
        .custom(async (value, { req }) => {
            const group = await ACLGroup.findOne({
                ...aclGroupsQuery(req),
                name: req.body.group
            });
            if(!group) throw new Error(req.t('routes.aclgroup.errors.group_not_found'));
            req.modifiedBody.group = group;
        }),
    body('group')
        .if((value, { req }) => !req.isAPI)
        .isUUID()
        .custom(async (value, { req }) => {
            const group = await ACLGroup.findOne({
                ...aclGroupsQuery(req),
                uuid: req.body.group
            });
            if(!group) throw new Error(req.t('routes.aclgroup.errors.group_not_found'));
            req.modifiedBody.group = group;
        }),
    body('mode')
        .customSanitizer(value => value ?? 'ip'),
        // .isIn(['ip', 'username']),
    body('ip')
        .if(body('mode').equals('ip'))
        .notEmpty()
        .custom((value, { req }) => {
            const ipv4 = Address4.isValid(value);
            const ipv6 = Address6.isValid(value);
            if(!ipv4 && !ipv6) throw new Error('invalid_cidr');

            if(ipv4 && req.modifiedBody.group.maxIpv4Cidr) {
                const addr = new Address4(value);
                if(addr.subnetMask < req.modifiedBody.group.maxIpv4Cidr)
                    throw new Error(req.t('routes.aclgroup.errors.aclgroup_config', { key: 'max_ipv4_cidr', value: '/' + req.modifiedBody.group.maxIpv4Cidr }));
            }
            if(ipv6 && req.modifiedBody.group.maxIpv6Cidr) {
                const addr = new Address6(value);
                if(addr.subnetMask < req.modifiedBody.group.maxIpv6Cidr)
                    throw new Error(req.t('routes.aclgroup.errors.aclgroup_config', { key: 'max_ipv6_cidr', value: '/' + req.modifiedBody.group.maxIpv6Cidr }));
            }

            return true;
        }),
    body('username')
        .if(body('mode').equals('username'))
        .notEmpty()
        .custom(async (value, { req }) => {
            const user = await User.findOne({
                name: {
                    $regex: new RegExp(`^${utils.escapeRegExp(value)}$`, 'i')
                }
            });
            if(!user || !value) throw new Error(req.t('routes.aclgroup.errors.invalid_username'));

            req.modifiedBody.user = user;
        }),
    body('note')
        .notEmpty()
        .withMessage('errors.required_field'),
    body('duration')
        .custom((value, { req }) => {
            let result;
            if(value === 'raw') {
                const rawDuration = req.body.rawDuration;
                const rawMultiplier = req.body.rawMultiplier;

                if(!rawDuration) throw new Error(req.t('errors.required_field'));

                const customValue = rawDuration * rawMultiplier;
                req.modifiedBody.duration = customValue;
                if(customValue < 0) throw new Error(req.t('routes.aclgroup.errors.min_duration'));
                result = !isNaN(customValue);
            }
            else {
                req.modifiedBody.duration = Number(value);
                if(value < 0) throw new Error(req.t('routes.aclgroup.errors.min_duration'));
                result = !isNaN(value);
            }

            if(req.body.mode === 'username'
                && req.modifiedBody.group.maxDurationAccount
                && (!req.modifiedBody.duration || req.modifiedBody.duration > req.modifiedBody.group.maxDurationAccount))
                throw new Error(req.t('routes.aclgroup.errors.aclgroup_config', { key: 'max_duration_account', value: req.modifiedBody.group.maxDurationAccount }));
            if(req.body.mode === 'ip'
                && req.modifiedBody.group.maxDurationIp
                && (!req.modifiedBody.duration || req.modifiedBody.duration > req.modifiedBody.group.maxDurationIp))
                throw new Error(req.t('routes.aclgroup.errors.aclgroup_config', { key: 'max_duration_ip', value: req.modifiedBody.group.maxDurationIp }));
            if(req.modifiedBody.group.maxDuration
                && (!req.modifiedBody.duration || req.modifiedBody.duration > req.modifiedBody.group.maxDuration))
                throw new Error(req.t('routes.aclgroup.errors.aclgroup_config', { key: 'max_duration', value: req.modifiedBody.group.maxDuration }));

            return result;
        }),
    body('hidelog')
        .custom((value, { req }) => {
            if(value === 'Y' && !req.permissions.includes('aclgroup_hidelog')) throw new Error(req.t('errors.missing_permission'));
            return true;
        }),
    middleware.fieldErrors
];
module.exports.postACLGroupValidate = postACLGroupValidate;

const addACLGroupItem = async ({ createdUser, createdUserUuid, group, groupName, ip, uuid, user, duration, note, hideLog = false }) => {
    if(groupName) group ??= await ACLGroup.findOne({ name: groupName });
    if(createdUserUuid) createdUser ??= await User.findOne({ uuid: createdUserUuid });
    if(uuid) user ??= await User.findOne({ uuid });

    if(!group || !createdUser || (!ip && !user) || !note) throw new Error('Invalid parameters');

    const newItem = {
        aclGroup: group.uuid,
        note
    }

    if(ip) newItem.ip = ip;
    else newItem.user = user.uuid;

    if(duration > 0) newItem.expiresAt = new Date(Date.now() + duration);

    let aclGroupItem;
    try {
        aclGroupItem = await ACLGroupItem.create(newItem);
    } catch (e) {
        if(e.code === 11000) return null;
        throw e;
    }

    await BlockHistory.create({
        type: BlockHistoryTypes.ACLGroupAdd,
        createdUser: createdUser.uuid,
        ...(ip ? {
            targetContent: ip
        } : {
            targetUser: user.uuid,
            targetUsername: user.name
        }),
        aclGroup: group.uuid,
        aclGroupName: group.name,
        aclGroupId: aclGroupItem.id,
        ...(duration > 0 ? {
            duration
        } : {}),
        content: note,
        hideLog
    });

    return aclGroupItem;
}
module.exports.addACLGroupItem = addACLGroupItem;

const postACLGroup = async (req, res) => {
    const group = req.modifiedBody.group;

    if(!groupPermChecker(req, group, 'addPerms')) return res.status(403).send(req.t('errors.missing_permission'));

    const aclGroupItem = await addACLGroupItem({
        createdUser: req.user,
        group,
        ...(req.body.mode === 'ip' ? {
            ip: req.body.ip
        } : {
            user: req.modifiedBody.user
        }),
        duration: req.modifiedBody.duration * 1000,
        note: req.body.note,
        hideLog: req.body.hidelog === 'Y'
    });
    if(!aclGroupItem) return res.status(409).send(req.t('routes.aclgroup.errors.dup_aclgroup_item'));

    if(req.isAPI) res.sendData({ id: aclGroupItem.id });
    else if(req.referer?.pathname.startsWith('/aclgroup')) {
        res.reload();
    }
    else res.status(204).end();
}
module.exports.postACLGroup = postACLGroup;

app.post('/aclgroup', ...postACLGroupValidate, postACLGroup);

const removeACLGroupValidate = [
    (req, res, next) => {
        req.modifiedBody = {};
        next();
    },
    body('id')
        .if((value, { req }) => req.isAPI)
        .isInt({ min: 1 })
        .toInt(),
    body('uuid')
        .if((value, { req }) => !req.isAPI)
        .isUUID(),
    body('group')
        .if((value, { req }) => req.isAPI)
        .isString()
        .custom(async (value, { req }) => {
            const group = await ACLGroup.findOne({
                ...aclGroupsQuery(req),
                name: req.body.group
            });
            if(!group) throw new Error(req.t('routes.aclgroup.errors.group_not_found'));
            req.modifiedBody.group = group;
        }),
    body('group')
        .if((value, { req }) => !req.isAPI)
        .isUUID()
        .custom(async (value, { req }) => {
            const group = await ACLGroup.findOne({
                ...aclGroupsQuery(req),
                uuid: req.body.group
            });
            if(!group) throw new Error(req.t('routes.aclgroup.errors.group_not_found'));
            req.modifiedBody.group = group;
        }),
    body('note')
        .notEmpty()
        .withMessage('errors.required_field'),
    body('hidelog')
        .custom((value, { req }) => {
            if(value === 'Y' && !req.permissions.includes('aclgroup_hidelog')) throw new Error(req.t('errors.missing_permission'));
            return true;
        }),
    middleware.fieldErrors
];
module.exports.removeACLGroupValidate = removeACLGroupValidate;

const removeACLGroupItem = async ({ createdUser, createdUserUuid, group, id, uuid, note, hideLog = false }) => {
    if(createdUserUuid) createdUser ??= await User.findOne({ uuid: createdUserUuid });

    if(!createdUser || (!id && !uuid) || !note) throw new Error('Invalid parameters');

    const deleted = await ACLGroupItem.findOneAndDelete(id ? {
        id
    } : {
        uuid
    });
    if(!deleted) return null;

    let targetUser;
    if(deleted.user) targetUser = await User.findOne({
        uuid: deleted.user
    });

    group ??= await ACLGroup.findOne({
        uuid: deleted.aclGroup
    });

    await BlockHistory.create({
        type: BlockHistoryTypes.ACLGroupRemove,
        createdUser: createdUser.uuid,
        ...(deleted.user == null ? {
            targetContent: deleted.ip
        } : {
            targetUser: targetUser?.uuid || deleted.user,
            targetUsername: targetUser?.name
        }),
        aclGroup: deleted.aclGroup,
        aclGroupName: group.name,
        aclGroupId: deleted.id,
        content: note,
        hideLog
    });

    return deleted;
}

const removeACLGroup = async (req, res) => {
    const group = req.modifiedBody.group;

    if(!groupPermChecker(req, group, 'removePerms')) return res.status(403).send(req.t('errors.missing_permission'));

    const deleted = await removeACLGroupItem({
        createdUser: req.user,
        group,
        ...(req.isAPI ? {
            id: req.body.id
        } : {
            uuid: req.body.uuid
        }),
        note: req.body.note,
        hideLog: req.body.hidelog === 'Y'
    });
    if(!deleted) return res.status(404).send(req.t('routes.aclgroup.errors.aclgroup_item_not_found'));

    res.reload();
}
module.exports.removeACLGroup = removeACLGroup;

app.post('/aclgroup/remove', ...removeACLGroupValidate, removeACLGroup);

app.get('/aclgroup/group_manage', async (req, res) => {
    const group = await ACLGroup.findOne({
        name: req.query.name
    });
    if(!group
        || !groupPermChecker(req, group, 'managePerms'))
        return res.error(req.t('routes.aclgroup.errors.group_not_found'), 404);

    return res.renderSkin('aclgroup_manage', {
        contentName: 'admin/aclgroupManage',
        serverData: {
            group: Object.fromEntries(Object.entries(utils.withoutKeys(group, [
                '_id',
                '__v'
            ])).map(([k, v]) => {
                if(Array.isArray(v)) v = v.join(',');
                else if(typeof v !== 'boolean') v = v.toString();
                return [k, v];
            }))
        }
    });
});

const permValidator = field => body(field)
    .customSanitizer(value => [...new Set((value ?? '').split(',').map(a => a.trim()).filter(a => a))])
    .custom((value, { req }) => {
        const invalid = value.find(a => !['any', ...AllPermissions].includes(a));
        if(invalid)
            throw new Error(req.t('routes.aclgroup.errors.invalid_permission', { value: invalid }));
        if(field === 'managePerms'
            && (
                (value.length && !req.permissions.some(a => value.includes(a)))
                || (!value.length && !req.permissions.includes('aclgroup'))
            ))
            throw new Error(req.t('routes.aclgroup.errors.missing_self_permission'));
        if(field === 'permissions') {
            const groupPermissions = req.body.group.permissions;
            const addedPermissions = value.filter(a => !groupPermissions.includes(a));
            const removedPermissions = groupPermissions.filter(a => !value.includes(a)
                && !NoGrantPermissions.includes(a)
                && !AlwaysProtectedPermissions.includes(a));
            const modifiedPermissions = [
                ...addedPermissions,
                ...removedPermissions
            ];
            if(modifiedPermissions.length && !req.permissions.includes('grant'))
                throw new Error(req.t('routes.aclgroup.errors.modify_value_missing_permission', { value: 'grant' }));

            const addablePermissions = AllPermissions.filter(a =>
                !NoGrantPermissions.includes(a)
                && (req.permissions.includes(a) || !ProtectedPermissions.includes(a))
                && !AlwaysProtectedPermissions.includes(a)
                && (req.permissions.includes('config') || config.grant_permissions.includes(a) || req.permissions.includes(a)));

            const noGrantablePermission = modifiedPermissions.find(a => !addablePermissions.includes(a));
            if(noGrantablePermission)
                throw new Error(req.t('routes.aclgroup.errors.missing_permission_edit_permission', { value: noGrantablePermission }));
        }
        return true;
    });

app.post('/aclgroup/group_manage',
    body('uuid')
        .custom(async (value, { req }) => {
            const group = await ACLGroup.findOne({
                uuid: value
            });
            if(!group
                || !groupPermChecker(req, group, 'managePerms'))
                throw new Error(req.t('routes.aclgroup.errors.group_not_found'));

            req.body.group = group;
        }),
    body('name')
        .notEmpty()
        .withMessage('routes.aclgroup.errors.group_name_required'),
    body('withdrawPeriodHours')
        .isInt({ min: 0 }),
    body('signupPolicy')
        .isInt({
            min: Math.min(...Object.values(SignupPolicy)),
            max: Math.max(...Object.values(SignupPolicy))
        }),
    body('maxDuration')
        .isInt({ min: 0 }),
    body('maxDurationIp')
        .isInt({ min: 0 }),
    body('maxDurationAccount')
        .isInt({ min: 0 }),
    body('maxIpv4Cidr')
        .isInt({ min: 0, max: 32 }),
    body('maxIpv6Cidr')
        .isInt({ min: 0, max: 128 }),
    permValidator('accessPerms'),
    permValidator('addPerms'),
    permValidator('removePerms'),
    permValidator('managePerms'),
    body('userCSS')
        .customSanitizer((value, { req }) => {
            if(req.body.group.userCSS !== value
                && !req.permissions.includes('config'))
                value = namumarkUtils.cssFilter(value);
            return value;
        }),
    body('aclMessage')
        .customSanitizer(value => namumarkUtils.baseSanitizeHtml(value)),
    permValidator('permissions'),
    body('captchaRate')
        .isInt({ min: 0 }),
    middleware.fieldErrors,
    async (req, res) => {
    const group = req.body.group;

    await ACLGroup.findOneAndUpdate({
        uuid: group.uuid
    }, {
        name: req.body.name,
        withdrawPeriodHours: req.body.withdrawPeriodHours,
        signupPolicy: req.body.signupPolicy,
        maxDuration: req.body.maxDuration,
        maxDurationIp: req.body.maxDurationIp,
        maxDurationAccount: req.body.maxDurationAccount,
        maxIpv4Cidr: req.body.maxIpv4Cidr,
        maxIpv6Cidr: req.body.maxIpv6Cidr,
        accessPerms: req.body.accessPerms,
        addPerms: req.body.addPerms,
        removePerms: req.body.removePerms,
        managePerms: req.body.managePerms,
        userCSS: req.body.userCSS,
        aclMessage: req.body.aclMessage,
        selfRemoveNote: req.body.selfRemoveNote,
        forBlock: req.body.forBlock === 'Y',
        selfRemovable: req.body.selfRemovable === 'Y',
        permissions: req.body.permissions,
        captchaRate: req.body.captchaRate
    });

    if(req.body.name === group.name) res.reload();
    else res.redirect(`/aclgroup/group_manage?name=${encodeURIComponent(req.body.name)}`);
});

app.get('/aclgroup/self_remove', async (req, res) => {
    const item = await ACLGroupItem.findOne({
        id: req.query.id
    });
    if(!item || !req.query.id || (item.user !== req.user.uuid && item.ip !== req.ip)) return res.error('aclgroup_not_found');

    const group = await ACLGroup.findOne({
        uuid: item.aclGroup
    });
    if(!group.selfRemovable) return res.error(req.t('routes.aclgroup.errors.not_self_removable'));

    await ACLGroupItem.deleteOne({
        uuid: item.uuid
    });

    await BlockHistory.create({
        type: BlockHistoryTypes.ACLGroupRemove,
        createdUser: req.user.uuid,
        ...(item.user == null ? {
            targetContent: item.ip
        } : {
            targetUser: req.user.uuid,
            targetUsername: req.user.name
        }),
        aclGroup: item.aclGroup,
        aclGroupName: group.name,
        aclGroupId: item.id,
        content: group.selfRemoveNote || 'SELF REMOVE'
    });

    res.reload(null, true);
});

module.exports.router = app;